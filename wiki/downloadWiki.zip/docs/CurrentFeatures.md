The current version only supports UnitTest aka TestMethods, so other kind of Tests will generate an error:

* WebTests
* LoadTests
* ManualTests
* OrderedTests
* TestMethods with databinding

