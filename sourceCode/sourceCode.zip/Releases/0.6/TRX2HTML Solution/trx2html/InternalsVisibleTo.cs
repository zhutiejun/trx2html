﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleTo("trx2html.Test")]
